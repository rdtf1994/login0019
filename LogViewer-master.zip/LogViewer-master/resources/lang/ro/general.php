<?php

return [
    'all'        => 'Toate',
    'date'       => 'Dată',
    'empty-logs' => 'Nu există niciun log!',
];
