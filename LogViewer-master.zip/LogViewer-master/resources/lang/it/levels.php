<?php

return [
    'all'       => 'Tutti',
    'emergency' => 'Emergenza',
    'alert'     => 'Allarme',
    'critical'  => 'Critico',
    'error'     => 'Errore',
    'warning'   => 'Avviso',
    'notice'    => 'Notifica',
    'info'      => 'Info',
    'debug'     => 'Debug',
];
