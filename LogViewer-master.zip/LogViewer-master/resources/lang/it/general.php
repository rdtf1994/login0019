<?php

return [
    'all'        => 'Tutti',
    'date'       => 'Data',
    'empty-logs' => 'L\'elenco dei log è vuoto!',
];
