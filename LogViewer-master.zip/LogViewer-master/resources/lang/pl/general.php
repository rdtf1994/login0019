<?php

return [
    'all'        => 'Wszystkie',
    'date'       => 'Data',
    'empty-logs' => 'Lista logów jest pusta!',
];
