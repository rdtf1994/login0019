<?php

return [
    'all'        => 'Alla',
    'date'       => 'Datum',
    'empty-logs' => 'Det finns inga loggar att visa.',
];
