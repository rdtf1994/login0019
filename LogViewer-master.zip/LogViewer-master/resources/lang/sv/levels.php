<?php

return [
    'all'       => 'Alla',
    'emergency' => 'Akut',
    'alert'     => 'Alarmerande',
    'critical'  => 'Kritisk',
    'error'     => 'Error',
    'warning'   => 'Varning',
    'notice'    => 'Notis',
    'info'      => 'Information',
    'debug'     => 'Debug',
];
