<?php

return [
    'all'        => 'Semua',
    'date'       => 'Tanggal',
    'empty-logs' => 'Daftar Log Kosong',
];
