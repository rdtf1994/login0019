<?php

return [
    'all'        => 'Alle',
    'date'       => 'Datum',
    'empty-logs' => 'Keine Log Dateien gefunden!',
];
