<?php

return [
    'all'        => 'Все',
    'date'       => 'Дата',
    'empty-logs' => 'Список журналов пуст!',
];
