<?php

return [
    'all'        => 'ทั้งหมด',
    'date'       => 'วันที่',
    'empty-logs' => 'ไม่มีรายการล็อก!',
];
