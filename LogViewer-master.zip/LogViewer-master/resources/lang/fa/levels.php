<?php

return [
    'all'       => 'همه',
    'emergency' => 'اورژانسی',
    'alert'     => 'اخطار',
    'critical'  => 'بحرانی',
    'error'     => 'خطا',
    'warning'   => 'هشدار',
    'notice'    => 'اعلان',
    'info'      => 'اطلاعات',
    'debug'     => 'دیباگ',
];
